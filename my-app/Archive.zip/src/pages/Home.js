import React from 'react'
import {InputGroup, FormControl} from 'react-bootstrap'

function Home() {
 
    return (
        <div>
          <h1>Home</h1>
           </div>
    )
}

export default Home
