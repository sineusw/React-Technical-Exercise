export default [
    {
        id: 1,
        username: "user1",
        email: 'user@example.com', 
        password: 'password'
    }
]